---
name: refreshList
component: ionRefresher
---
