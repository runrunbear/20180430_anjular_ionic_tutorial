var DEMOS = {$ doc.demos | json $};
